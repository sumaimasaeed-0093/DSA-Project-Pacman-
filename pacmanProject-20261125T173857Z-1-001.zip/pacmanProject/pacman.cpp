#include <iostream>
#include <string>
#include <fstream>
#include <ctime>
#include <SFML/Graphics.hpp>
using namespace std;

template <typename T>
class SafeArray {
private:
    T* data;
    int count;   
    int cap;     

    void reallocate(int newCap) {
        T* nd = new T[newCap]();
        for (int i = 0; i < count; i++) nd[i] = data[i];
        delete[] data;
        data = nd;
        cap = newCap;
    }

public:
    SafeArray() : data(nullptr), count(0), cap(0) {}

    explicit SafeArray(int n) : data(nullptr), count(0), cap(0) {
        if (n < 0) throw "SafeArray: negative size";
        if (n > 0) { data = new T[n](); cap = n; count = n; }
    }

    
    SafeArray(const SafeArray& other) : data(nullptr), count(0), cap(0) {
        if (other.count > 0) {
            data = new T[other.count]();
            cap = other.count;
            count = other.count;
            for (int i = 0; i < count; i++) data[i] = other.data[i];
        }
    }

    
    SafeArray& operator=(const SafeArray& other) {
        if (this == &other) return *this;
        T* nd = nullptr;
        if (other.count > 0) {
            nd = new T[other.count]();
            for (int i = 0; i < other.count; i++) nd[i] = other.data[i];
        }
        delete[] data;
        data = nd;
        count = other.count;
        cap = other.count;
        return *this;
    }

    
    ~SafeArray() { delete[] data; }

    int size() const { return count; }
    bool isEmpty() const { return count == 0; }

    T& operator[](int i) {
        if (i < 0 || i >= count) throw "SafeArray: index out of range";
        return data[i];
    }
    const T& operator[](int i) const {
        if (i < 0 || i >= count) throw "SafeArray: index out of range";
        return data[i];
    }

    void push_back(const T& v) {
        T copy = v;  
        if (count == cap) reallocate(cap == 0 ? 4 : cap * 2);
        data[count++] = copy;
    }

    T pop_back() {
        if (count == 0) throw "SafeArray: pop from empty array";
        return data[--count];
    }

    void clear() { count = 0; }

    void resize(int n) {
        if (n < 0) throw "SafeArray: negative size";
        if (n > cap) reallocate(n);
        for (int i = count; i < n; i++) data[i] = T();
        count = n;
    }

    void fill(const T& v) {
        for (int i = 0; i < count; i++) data[i] = v;
    }
};

template <typename T>
class SinglyLinkedList {
private:
    struct Node {
        T data;
        Node* next;
        Node(const T& d) : data(d), next(nullptr) {}
    };
    Node* head;
    Node* tail;
    int count;

public:
    SinglyLinkedList() : head(nullptr), tail(nullptr), count(0) {}
    ~SinglyLinkedList() { clear(); }
    SinglyLinkedList(const SinglyLinkedList&) = delete;
    SinglyLinkedList& operator=(const SinglyLinkedList&) = delete;

    int size() const { return count; }

    
    void pushBack(const T& v) {
        Node* n = new Node(v);
        if (tail == nullptr) head = tail = n;
        else { tail->next = n; tail = n; }
        count++;
    }

    
    T& getAt(int index) {
        if (index < 0 || index >= count) throw "SinglyLinkedList: index out of range";
        Node* p = head;
        for (int i = 0; i < index; i++) p = p->next;
        return p->data;
    }

    
    void removeAt(int index) {
        if (index < 0 || index >= count) throw "SinglyLinkedList: index out of range";
        Node* prev = nullptr;
        Node* cur = head;
        for (int i = 0; i < index; i++) { prev = cur; cur = cur->next; }
        if (prev == nullptr) head = cur->next;
        else prev->next = cur->next;
        if (cur == tail) tail = prev;
        delete cur;
        count--;
    }

    void clear() {
        while (head != nullptr) {
            Node* nx = head->next;
            delete head;
            head = nx;
        }
        tail = nullptr;
        count = 0;
    }
};

template <typename T>
class DoublyLinkedList {
private:
    struct Node {
        T data;
        Node* prev;
        Node* next;
        Node(const T& d) : data(d), prev(nullptr), next(nullptr) {}
    };
    Node* head;
    Node* tail;
    int count;

public:
    DoublyLinkedList() : head(nullptr), tail(nullptr), count(0) {}
    ~DoublyLinkedList() { clear(); }
    DoublyLinkedList(const DoublyLinkedList&) = delete;
    DoublyLinkedList& operator=(const DoublyLinkedList&) = delete;

    int size() const { return count; }

    void pushFront(const T& v) {
        Node* n = new Node(v);
        n->next = head;
        if (head != nullptr) head->prev = n;
        head = n;
        if (tail == nullptr) tail = n;
        count++;
    }

    T& back() {
        if (tail == nullptr) throw "DoublyLinkedList: empty";
        return tail->data;
    }

    void popBack() {
        if (tail == nullptr) throw "DoublyLinkedList: empty";
        Node* old = tail;
        tail = tail->prev;
        if (tail != nullptr) tail->next = nullptr;
        else head = nullptr;
        delete old;
        count--;
    }

    void clear() {
        while (head != nullptr) {
            Node* nx = head->next;
            delete head;
            head = nx;
        }
        tail = nullptr;
        count = 0;
    }
};

template <typename T>
class Stack {
private:
    struct Node {
        T data;
        Node* next;
        Node(const T& d, Node* n) : data(d), next(n) {}
    };
    Node* topNode;

public:
    Stack() : topNode(nullptr) {}
    ~Stack() { while (topNode != nullptr) pop(); }
    Stack(const Stack&) = delete;
    Stack& operator=(const Stack&) = delete;

    bool isEmpty() const { return topNode == nullptr; }

    void push(const T& v) { topNode = new Node(v, topNode); }

    T pop() {
        if (topNode == nullptr) throw "Stack: pop from empty stack";
        Node* old = topNode;
        T v = old->data;
        topNode = old->next;
        delete old;
        return v;
    }
};

template <typename T>
class Queue {
private:
    struct Node {
        T data;
        Node* next;
        Node(const T& d) : data(d), next(nullptr) {}
    };
    Node* frontNode;
    Node* rearNode;

public:
    Queue() : frontNode(nullptr), rearNode(nullptr) {}
    ~Queue() { clear(); }
    Queue(const Queue&) = delete;
    Queue& operator=(const Queue&) = delete;

    bool isEmpty() const { return frontNode == nullptr; }

    void enqueue(const T& v) {
        Node* n = new Node(v);
        if (rearNode == nullptr) frontNode = rearNode = n;
        else { rearNode->next = n; rearNode = n; }
    }

    T dequeue() {
        if (frontNode == nullptr) throw "Queue: dequeue from empty queue";
        Node* old = frontNode;
        T v = old->data;
        frontNode = old->next;
        if (frontNode == nullptr) rearNode = nullptr;
        delete old;
        return v;
    }

    void clear() { while (frontNode != nullptr) dequeue(); }
};

struct HeapEntry {
    int node;
    int priority;
    HeapEntry() : node(0), priority(0) {}
};

class MinHeap {
private:
    SafeArray<HeapEntry> a;   

    void siftUp(int i) {
        while (i > 0) {
            int p = (i - 1) / 2;
            if (a[p].priority <= a[i].priority) break;
            HeapEntry t = a[p]; a[p] = a[i]; a[i] = t;
            i = p;
        }
    }

    void siftDown(int i) {
        int n = a.size();
        while (true) {
            int l = 2 * i + 1, r = 2 * i + 2, m = i;
            if (l < n && a[l].priority < a[m].priority) m = l;
            if (r < n && a[r].priority < a[m].priority) m = r;
            if (m == i) break;
            HeapEntry t = a[m]; a[m] = a[i]; a[i] = t;
            i = m;
        }
    }

public:
    bool isEmpty() const { return a.isEmpty(); }

    void push(int node, int priority) {
        HeapEntry e;
        e.node = node;
        e.priority = priority;
        a.push_back(e);
        siftUp(a.size() - 1);
    }

    
    HeapEntry pop() {
        if (a.isEmpty()) throw "MinHeap: pop from empty heap";
        HeapEntry top = a[0];
        HeapEntry last = a.pop_back();
        if (!a.isEmpty()) { a[0] = last; siftDown(0); }
        return top;
    }
};

class FoodHashTable {
private:
    struct Node {
        int key;
        Node* next;
    };
    Node** table;
    int capacity;
    int count;

    static bool isPrime(int n) {
        if (n < 2) return false;
        for (int i = 2; i * i <= n; i++)
            if (n % i == 0) return false;
        return true;
    }

    static int nextPrime(int n) {
        while (!isPrime(n)) n++;
        return n;
    }

    
    void rehash() {
        int newCap = nextPrime(capacity * 2 + 1);
        Node** nt = new Node*[newCap]();
        for (int i = 0; i < capacity; i++) {
            Node* p = table[i];
            while (p != nullptr) {
                Node* nx = p->next;
                int idx = p->key % newCap;
                p->next = nt[idx];
                nt[idx] = p;
                p = nx;
            }
        }
        delete[] table;
        table = nt;
        capacity = newCap;
    }

public:
    FoodHashTable() : table(nullptr), capacity(11), count(0) {
        table = new Node*[capacity]();
    }

    ~FoodHashTable() {
        clear();
        delete[] table;
    }

    FoodHashTable(const FoodHashTable&) = delete;
    FoodHashTable& operator=(const FoodHashTable&) = delete;

    int size() const { return count; }

    bool contains(int key) const {
        for (Node* p = table[key % capacity]; p != nullptr; p = p->next)
            if (p->key == key) return true;
        return false;
    }

    void insert(int key) {
        if (contains(key)) return;
        if ((count + 1) * 4 > capacity * 3) rehash();   
        int idx = key % capacity;
        Node* n = new Node;
        n->key = key;
        n->next = table[idx];
        table[idx] = n;
        count++;
    }

    void remove(int key) {
        int idx = key % capacity;
        Node* prev = nullptr;
        Node* p = table[idx];
        while (p != nullptr) {
            if (p->key == key) {
                if (prev == nullptr) table[idx] = p->next;
                else prev->next = p->next;
                delete p;
                count--;
                return;
            }
            prev = p;
            p = p->next;
        }
    }

    void clear() {
        for (int i = 0; i < capacity; i++) {
            Node* p = table[i];
            while (p != nullptr) {
                Node* nx = p->next;
                delete p;
                p = nx;
            }
            table[i] = nullptr;
        }
        count = 0;
    }
};

class AVLTree {
private:
    struct Node {
        int score;
        Node* left;
        Node* right;
        int height;
        Node(int s) : score(s), left(nullptr), right(nullptr), height(1) {}
    };
    Node* root;

    static int h(Node* n) { return n == nullptr ? 0 : n->height; }

    static void update(Node* n) {
        int l = h(n->left), r = h(n->right);
        n->height = 1 + (l > r ? l : r);
    }

    static int balanceFactor(Node* n) { return h(n->left) - h(n->right); }

    static Node* rotateRight(Node* y) {
        Node* x = y->left;
        y->left = x->right;
        x->right = y;
        update(y);
        update(x);
        return x;
    }

    static Node* rotateLeft(Node* x) {
        Node* y = x->right;
        x->right = y->left;
        y->left = x;
        update(x);
        update(y);
        return y;
    }

    static Node* insertNode(Node* n, int score) {
        if (n == nullptr) return new Node(score);
        if (score < n->score) n->left = insertNode(n->left, score);
        else n->right = insertNode(n->right, score);
        update(n);
        int bf = balanceFactor(n);
        if (bf > 1) {                                    
            if (balanceFactor(n->left) < 0) n->left = rotateLeft(n->left);
            return rotateRight(n);
        }
        if (bf < -1) {                                   
            if (balanceFactor(n->right) > 0) n->right = rotateRight(n->right);
            return rotateLeft(n);
        }
        return n;
    }

    static void destroy(Node* n) {
        if (n == nullptr) return;
        destroy(n->left);
        destroy(n->right);
        delete n;
    }

    static void inorder(Node* n, SafeArray<int>& out) {
        if (n == nullptr) return;
        inorder(n->left, out);
        out.push_back(n->score);
        inorder(n->right, out);
    }

public:
    AVLTree() : root(nullptr) {}
    ~AVLTree() { destroy(root); }
    AVLTree(const AVLTree&) = delete;
    AVLTree& operator=(const AVLTree&) = delete;

    void insert(int score) { root = insertNode(root, score); }

    
    int highScore() const {
        if (root == nullptr) return 0;
        Node* p = root;
        while (p->right != nullptr) p = p->right;
        return p->score;
    }

    
    void toArray(SafeArray<int>& out) const {
        out.clear();
        inorder(root, out);
    }
};

void mergeRange(SafeArray<int>& a, SafeArray<int>& tmp, int lo, int mid, int hi) {
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        if (a[i] <= a[j]) tmp[k++] = a[i++];
        else tmp[k++] = a[j++];
    }
    while (i <= mid) tmp[k++] = a[i++];
    while (j <= hi) tmp[k++] = a[j++];
    for (k = lo; k <= hi; k++) a[k] = tmp[k];
}

void mergeSortRange(SafeArray<int>& a, SafeArray<int>& tmp, int lo, int hi) {
    if (lo >= hi) return;
    int mid = lo + (hi - lo) / 2;
    mergeSortRange(a, tmp, lo, mid);
    mergeSortRange(a, tmp, mid + 1, hi);
    mergeRange(a, tmp, lo, mid, hi);
}

void mergeSort(SafeArray<int>& a) {
    if (a.size() < 2) return;
    SafeArray<int> tmp(a.size());
    mergeSortRange(a, tmp, 0, a.size() - 1);
}

class Random {
private:
    unsigned int state;

public:
    explicit Random(unsigned int seed) : state(seed) {
        for (int i = 0; i < 5; i++) nextInt(100);
    }

    
    int nextInt(int n) {
        state = state * 1664525u + 1013904223u;
        return (int)((state >> 16) % (unsigned int)n);
    }
};

class Graph {
public:
    struct Edge {
        int to;
        Edge* next;
    };

private:
    int capacity;            
    int nodes;               
    Edge** adj;              
    SafeArray<char> present;

    void addDirected(int a, int b) {
        Edge* e = new Edge;
        e->to = b;
        e->next = adj[a];
        adj[a] = e;
    }

public:
    explicit Graph(int cells)
        : capacity(cells), nodes(0), adj(new Edge*[cells]()), present(cells) {}

    ~Graph() {
        for (int i = 0; i < capacity; i++) {
            Edge* p = adj[i];
            while (p != nullptr) {
                Edge* nx = p->next;
                delete p;
                p = nx;
            }
        }
        delete[] adj;
    }

    Graph(const Graph&) = delete;
    Graph& operator=(const Graph&) = delete;

    int nodeCount() const { return nodes; }
    const Edge* neighbors(int id) const { return adj[id]; }

    void addNode(int id) {
        if (!present[id]) { present[id] = 1; nodes++; }
    }

    void addUndirectedEdge(int a, int b) {
        addDirected(a, b);
        addDirected(b, a);
    }

    
    int dfsCount(int start) const {
        SafeArray<char> visited(capacity);
        Stack<int> st;
        int reached = 0;
        st.push(start);
        visited[start] = 1;
        while (!st.isEmpty()) {
            int u = st.pop();
            reached++;
            for (const Edge* e = adj[u]; e != nullptr; e = e->next) {
                if (!visited[e->to]) {
                    visited[e->to] = 1;
                    st.push(e->to);
                }
            }
        }
        return reached;
    }

    
    
    
    void bfsTree(int source, SafeArray<int>& parent) const {
        parent.resize(capacity);
        parent.fill(-2);
        Queue<int> q;
        parent[source] = -1;
        q.enqueue(source);
        while (!q.isEmpty()) {
            int u = q.dequeue();
            for (const Edge* e = adj[u]; e != nullptr; e = e->next) {
                if (parent[e->to] == -2) {
                    parent[e->to] = u;
                    q.enqueue(e->to);
                }
            }
        }
    }

    
    int bfsNextStep(int from, int to) const {
        if (from == to) return from;
        SafeArray<int> parent;
        bfsTree(to, parent);
        int p = parent[from];
        return p < 0 ? from : p;
    }

    
    
    int dijkstraNextStep(int from, int to, const SafeArray<int>& penalty) const {
        if (from == to) return from;
        const int INF = 1000000000;
        SafeArray<int> dist(capacity);
        SafeArray<int> prev(capacity);
        dist.fill(INF);
        prev.fill(-1);
        MinHeap heap;
        dist[from] = 0;
        heap.push(from, 0);
        while (!heap.isEmpty()) {
            HeapEntry top = heap.pop();
            int u = top.node;
            if (top.priority > dist[u]) continue;        
            if (u == to) break;
            for (const Edge* e = adj[u]; e != nullptr; e = e->next) {
                int cost = dist[u] + 1 + penalty[e->to];
                if (cost < dist[e->to]) {
                    dist[e->to] = cost;
                    prev[e->to] = u;
                    heap.push(e->to, cost);
                }
            }
        }
        if (dist[to] == INF) return from;
        int cur = to;
        while (prev[cur] != from) cur = prev[cur];
        return cur;
    }
};

class Maze {
public:
    SafeArray<char> grid;         
    SafeArray<int> ghostStarts;   
    int rows;
    int cols;
    int startRow;
    int startCol;

    Maze() : rows(0), cols(0), startRow(-1), startCol(-1) {}

    int id(int r, int c) const { return r * cols + c; }

    bool isWalkable(int r, int c) const {
        if (r < 0 || r >= rows || c < 0 || c >= cols) return false;
        return grid[id(r, c)] != '#';
    }

    int foodCount() const {
        int n = 0;
        for (int i = 0; i < grid.size(); i++)
            if (grid[i] == '.') n++;
        return n;
    }

    
    bool loadFromFile(const string& filename) {
        ifstream in(filename.c_str());
        if (!in) return false;

        SafeArray<string> lines;
        string line;
        while (getline(in, line)) {
            while (!line.empty() && (line[line.size() - 1] == '\r' || line[line.size() - 1] == ' '))
                line.erase(line.size() - 1);
            if (!line.empty()) lines.push_back(line);
        }
        if (lines.size() < 3) return false;

        rows = lines.size();
        cols = (int)lines[0].size();
        if (cols < 3) return false;
        for (int r = 0; r < rows; r++)
            if ((int)lines[r].size() != cols) return false;

        grid = SafeArray<char>(rows * cols);
        ghostStarts.clear();
        int players = 0;

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                char ch = lines[r][c];
                if (ch == '#' || ch == '.' || ch == '-') {
                    grid[id(r, c)] = ch;
                } else if (ch == 'P') {
                    players++;
                    startRow = r;
                    startCol = c;
                    grid[id(r, c)] = '-';
                } else if (ch == 'G') {
                    ghostStarts.push_back(id(r, c));
                    grid[id(r, c)] = '-';
                } else {
                    return false;
                }
            }
        }
        return players == 1 && ghostStarts.size() >= 1 && foodCount() >= 1;
    }

    
    void buildGraph(Graph& g) const {
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                if (!isWalkable(r, c)) continue;
                g.addNode(id(r, c));
                if (isWalkable(r, c + 1)) g.addUndirectedEdge(id(r, c), id(r, c + 1));
                if (isWalkable(r + 1, c)) g.addUndirectedEdge(id(r, c), id(r + 1, c));
            }
        }
    }

    
    
    int searchFood(int r, int c, SafeArray<char>& visited) const {
        if (!isWalkable(r, c)) return 0;
        int cell = id(r, c);
        if (visited[cell]) return 0;
        visited[cell] = 1;
        int found = (grid[cell] == '.') ? 1 : 0;
        found += searchFood(r - 1, c, visited);
        found += searchFood(r + 1, c, visited);
        found += searchFood(r, c - 1, visited);
        found += searchFood(r, c + 1, visited);
        return found;
    }

    
    
    bool validate() const {
        SafeArray<char> visited(rows * cols);
        if (searchFood(startRow, startCol, visited) != foodCount()) return false;
        Graph g(rows * cols);
        buildGraph(g);
        return g.dfsCount(id(startRow, startCol)) == g.nodeCount();
    }
};

class MazeLibrary {
private:
    SinglyLinkedList<Maze> mazes;
    int lastPicked;

public:
    MazeLibrary() : lastPicked(-1) {}

    int size() const { return mazes.size(); }

    
    void load(const string& listFile) {
        ifstream in(listFile.c_str());
        string file;
        while (in >> file) {
            Maze m;
            if (m.loadFromFile(file) && m.validate()) mazes.pushBack(m);
        }
    }

    
    const Maze& pickRandom(Random& rng) {
        int idx = 0;
        if (mazes.size() > 1) {
            do { idx = rng.nextInt(mazes.size()); } while (idx == lastPicked);
        }
        lastPicked = idx;
        return mazes.getAt(idx);
    }
};

const string MAZE_LIST_FILE = "maze_list.txt";
const string SCORE_FILE = "scores.txt";
const int TRAIL_MAX = 6;     
const int MAX_GHOSTS = 3;

struct Ghost {
    int node;       
    int type;       
    bool released;  
    Ghost() : node(0), type(0), released(false) {}
};

class Game {
private:
    MazeLibrary library;
    Random rng;
    AVLTree scores;
    Maze maze;
    Graph* graph;
    FoodHashTable food;
    DoublyLinkedList<int> trail;
    SafeArray<Ghost> ghosts;
    Queue<int> waiting;            
    SafeArray<int> treeParent;

    int playerRow, playerCol;
    int level;
    int levelsCompleted;
    int turn;
    int releaseTimer;
    bool gameOver;
    string message;

    int playerNode() const { return maze.id(playerRow, playerCol); }

    int releaseGap() const { return (6 - level) > 2 ? (6 - level) : 2; }

    void clearScreen() const {
        for (int i = 0; i < 30; i++) cout << "\n";
    }

    
    
    void insertBalanced(SafeArray<int>& sorted, int lo, int hi) {
        if (lo > hi) return;
        int mid = lo + (hi - lo) / 2;
        scores.insert(sorted[mid]);
        insertBalanced(sorted, lo, mid - 1);
        insertBalanced(sorted, mid + 1, hi);
    }

    
    void loadScores() {
        SafeArray<int> list;
        ifstream in(SCORE_FILE.c_str());
        int s;
        while (in >> s) list.push_back(s);
        mergeSort(list);
        insertBalanced(list, 0, list.size() - 1);
    }

    void saveScores() {
        SafeArray<int> all;
        scores.toArray(all);
        ofstream out(SCORE_FILE.c_str());
        for (int i = 0; i < all.size(); i++) out << all[i] << "\n";
    }

    int currentHighScore() const {
        int best = scores.highScore();
        return levelsCompleted > best ? levelsCompleted : best;
    }

    
    void startLevel() {
        maze = library.pickRandom(rng);
        delete graph;
        graph = new Graph(maze.rows * maze.cols);
        maze.buildGraph(*graph);

        food.clear();
        for (int r = 0; r < maze.rows; r++)
            for (int c = 0; c < maze.cols; c++)
                if (maze.grid[maze.id(r, c)] == '.') food.insert(maze.id(r, c));

        playerRow = maze.startRow;
        playerCol = maze.startCol;
        trail.clear();
        trail.pushFront(playerNode());

        
        int count = level + 1;
        if (count > MAX_GHOSTS) count = MAX_GHOSTS;
        if (count > maze.ghostStarts.size()) count = maze.ghostStarts.size();
        ghosts.clear();
        waiting.clear();
        for (int i = 0; i < count; i++) {
            Ghost g;
            g.node = maze.ghostStarts[i];
            g.type = i;
            ghosts.push_back(g);
            waiting.enqueue(i);
        }
        turn = 0;
        releaseTimer = releaseGap();
    }

    bool ghostAt(int cell) const {
        for (int i = 0; i < ghosts.size(); i++)
            if (ghosts[i].node == cell) return true;
        return false;
    }

    void render() const {
        clearScreen();
        cout << "PAC-MAN    Level: " << level << "    Score: " << levelsCompleted
             << "    Food left: " << food.size() << "\n\n";

        for (int r = 0; r < maze.rows; r++) {
            string line = "  ";
            for (int c = 0; c < maze.cols; c++) {
                int cell = maze.id(r, c);
                if (maze.grid[cell] == '#') { line += "##"; continue; }
                char ch = ' ';
                if (food.contains(cell)) ch = '.';
                if (ghostAt(cell)) ch = 'G';
                if (r == playerRow && c == playerCol) ch = '@';
                line += ch;
                line += ' ';
            }
            cout << line << "\n";
        }

        cout << "\n  @ you   . food   # wall   G ghost\n";
        cout << "  High score: " << currentHighScore() << "\n";
        if (!message.empty()) cout << "\n" << message << "\n";
        cout << "\n";
    }

    
    void moveGhost(int i) {
        Ghost& gh = ghosts[i];
        int target = playerNode();
        int next = gh.node;

        if (gh.type == 0) {
            
            int p = treeParent[gh.node];
            if (p >= 0) next = p;
        } else if (gh.type == 1) {
            
            while (trail.size() > 1 && trail.back() == gh.node) trail.popBack();
            next = graph->bfsNextStep(gh.node, trail.back());
        } else {
            
            
            SafeArray<int> penalty(maze.rows * maze.cols);
            for (int j = 0; j < ghosts.size(); j++) {
                if (j == i || !ghosts[j].released) continue;
                penalty[ghosts[j].node] += 6;
                for (const Graph::Edge* e = graph->neighbors(ghosts[j].node); e != nullptr; e = e->next)
                    penalty[e->to] += 3;
            }
            next = graph->dijkstraNextStep(gh.node, target, penalty);
        }
        gh.node = next;
    }

    void advanceGhosts() {
        turn++;

        
        releaseTimer--;
        if (releaseTimer <= 0 && !waiting.isEmpty()) {
            ghosts[waiting.dequeue()].released = true;
            releaseTimer = releaseGap();
        }

        graph->bfsTree(playerNode(), treeParent);

        
        int skipEvery = level + 1;
        if (skipEvery <= 8 && turn % skipEvery == 0) return;

        for (int i = 0; i < ghosts.size(); i++) {
            if (!ghosts[i].released) continue;
            moveGhost(i);
            if (ghosts[i].node == playerNode()) {
                gameOver = true;
                return;
            }
        }
    }

    
    void processMove(char c) {
        int dr = 0, dc = 0;
        if (c >= 'A' && c <= 'Z') c = (char)(c + ('a' - 'A'));
        if (c == 'w') dr = -1;
        else if (c == 's') dr = 1;
        else if (c == 'a') dc = -1;
        else if (c == 'd') dc = 1;
        else return;

        int nr = playerRow + dr, nc = playerCol + dc;
        if (!maze.isWalkable(nr, nc)) return;      

        playerRow = nr;
        playerCol = nc;
        trail.pushFront(playerNode());
        if (trail.size() > TRAIL_MAX) trail.popBack();
        food.remove(playerNode());                 

        if (ghostAt(playerNode())) { gameOver = true; return; }

        if (food.size() == 0) {                    
            levelsCompleted++;
            level++;
            startLevel();
            message = "Level complete! New maze.";
            return;
        }
        advanceGhosts();
    }

public:
    Game() : rng((unsigned int)time(0)), graph(nullptr), playerRow(0), playerCol(0),
             level(1), levelsCompleted(0), turn(0), releaseTimer(0), gameOver(false) {}

    ~Game() { delete graph; }
    Game(const Game&) = delete;
    Game& operator=(const Game&) = delete;

    bool init() {
        library.load(MAZE_LIST_FILE);
        if (library.size() == 0) return false;
        loadScores();
        return true;
    }

    void play() {
        int savedBest = scores.highScore();
        startLevel();

        while (!gameOver) {
            render();
            message = "";
            string input;
            cout << "Move (w/a/s/d + Enter): ";
            if (!(cin >> input)) break;
            processMove(input[0]);
        }

        
        scores.insert(levelsCompleted);
        saveScores();
        message = "GAME OVER - levels completed: " + toText(levelsCompleted);
        if (levelsCompleted > savedBest) message += "   NEW HIGH SCORE!";
        render();
    }

    
    void playSFML() {
        const int tileSize = 28;
        const int hudHeight = 72;
        int savedBest = scores.highScore();
        startLevel();

        int windowWidth = maze.cols * tileSize;
        int windowHeight = maze.rows * tileSize + hudHeight;
        if (windowWidth < 640) windowWidth = 640;
        if (windowHeight < 480) windowHeight = 480;

        sf::RenderWindow window(sf::VideoMode(windowWidth, windowHeight), "Pac-Man - Data Structures");
        window.setFramerateLimit(60);

        sf::Font font;
        bool fontLoaded = font.loadFromFile("game_font.ttf");
        bool scoreSaved = false;
        int shownRows = maze.rows;
        int shownCols = maze.cols;

        while (window.isOpen()) {
            sf::Event event;
            while (window.pollEvent(event)) {
                if (event.type == sf::Event::Closed) window.close();
                if (event.type == sf::Event::KeyPressed) {
                    if (event.key.code == sf::Keyboard::Escape) window.close();
                    if (!gameOver) {
                        if (event.key.code == sf::Keyboard::Up || event.key.code == sf::Keyboard::W) processMove('w');
                        else if (event.key.code == sf::Keyboard::Down || event.key.code == sf::Keyboard::S) processMove('s');
                        else if (event.key.code == sf::Keyboard::Left || event.key.code == sf::Keyboard::A) processMove('a');
                        else if (event.key.code == sf::Keyboard::Right || event.key.code == sf::Keyboard::D) processMove('d');
                    }
                }
            }

            if (maze.rows != shownRows || maze.cols != shownCols) {
                shownRows = maze.rows;
                shownCols = maze.cols;
                int w = shownCols * tileSize;
                int h = shownRows * tileSize + hudHeight;
                if (w < 640) w = 640;
                if (h < 480) h = 480;
                window.setSize(sf::Vector2u(w, h));
                window.setView(sf::View(sf::FloatRect(0, 0, (float)w, (float)h)));
            }

            if (gameOver && !scoreSaved) {
                scores.insert(levelsCompleted);
                saveScores();
                message = "GAME OVER! Levels completed: " + toText(levelsCompleted);
                if (levelsCompleted > savedBest) message += " - NEW HIGH SCORE!";
                scoreSaved = true;
            }

            window.clear(sf::Color(12, 12, 28));

            if (fontLoaded) {
                sf::Text heading;
                heading.setFont(font);
                heading.setCharacterSize(20);
                heading.setFillColor(sf::Color::White);
                heading.setString("PAC-MAN     Level: " + toText(level) +
                                  "     Score: " + toText(levelsCompleted) +
                                  "     Food: " + toText(food.size()));
                heading.setPosition(10, 8);
                window.draw(heading);

                sf::Text help;
                help.setFont(font);
                help.setCharacterSize(13);
                help.setFillColor(sf::Color(190, 190, 210));
                help.setString("Move: Arrow Keys / WASD       Esc: Exit       High Score: " + toText(currentHighScore()));
                help.setPosition(10, 38);
                window.draw(help);
            }

            for (int r = 0; r < maze.rows; r++) {
                for (int c = 0; c < maze.cols; c++) {
                    int cell = maze.id(r, c);
                    float x = (float)c * tileSize;
                    float y = (float)r * tileSize + hudHeight;

                    sf::RectangleShape floor(sf::Vector2f((float)tileSize - 1, (float)tileSize - 1));
                    floor.setPosition(x, y);
                    floor.setFillColor(sf::Color(18, 18, 42));
                    window.draw(floor);

                    if (maze.grid[cell] == '#') {
                        sf::RectangleShape wall(sf::Vector2f((float)tileSize - 2, (float)tileSize - 2));
                        wall.setPosition(x + 1, y + 1);
                        wall.setFillColor(sf::Color(35, 85, 220));
                        wall.setOutlineThickness(1);
                        wall.setOutlineColor(sf::Color(90, 150, 255));
                        window.draw(wall);
                    } else if (food.contains(cell)) {
                        sf::CircleShape pellet(4);
                        pellet.setFillColor(sf::Color(255, 220, 170));
                        pellet.setPosition(x + tileSize / 2 - 4, y + tileSize / 2 - 4);
                        window.draw(pellet);
                    }
                }
            }

            for (int i = 0; i < ghosts.size(); i++) {
                if (!ghosts[i].released) continue;
                int gr = ghosts[i].node / maze.cols;
                int gc = ghosts[i].node % maze.cols;
                sf::CircleShape ghost((float)tileSize / 2 - 3);
                ghost.setPosition((float)gc * tileSize + 3, (float)gr * tileSize + hudHeight + 3);
                if (ghosts[i].type == 0) ghost.setFillColor(sf::Color(240, 65, 65));
                else if (ghosts[i].type == 1) ghost.setFillColor(sf::Color(255, 130, 190));
                else ghost.setFillColor(sf::Color(70, 220, 235));
                window.draw(ghost);
            }

            sf::CircleShape player((float)tileSize / 2 - 2);
            player.setPosition((float)playerCol * tileSize + 2,
                               (float)playerRow * tileSize + hudHeight + 2);
            player.setFillColor(sf::Color(255, 220, 0));
            window.draw(player);

            if (gameOver && fontLoaded) {
                sf::Text endText;
                endText.setFont(font);
                endText.setCharacterSize(24);
                endText.setFillColor(sf::Color::Red);
                endText.setString("GAME OVER - Press Esc to close");
                endText.setPosition(10, (float)window.getSize().y - 34);
                window.draw(endText);
            }

            window.display();
        }

        
        if (!scoreSaved) {
            scores.insert(levelsCompleted);
            saveScores();
        }
    }

    static string toText(int n) {
        if (n == 0) return "0";
        string s = "";
        while (n > 0) { s = (char)('0' + n % 10) + s; n /= 10; }
        return s;
    }
};

int main() {
    try {
        Game game;
        if (!game.init()) {
            cout << "No valid mazes found. Keep maze_list.txt and the maze files next to the program.\n";
            return 1;
        }
        game.playSFML();
    } catch (const char* msg) {
        cout << "Fatal error: " << msg << endl;
        return 1;
    }
    return 0;
}